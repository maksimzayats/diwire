import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent
OUT = ROOT/'evidence'
PYTHON = '/workspace/.venv/bin/python'
CONTAINER = 'diwire-five-proof-20261029'
HYPOTHESES = {'h001':'async_gen', 'h002':'scope', 'h003':'public_all', 'h004':'cleanup', 'h005':'origins'}

def run(source, label, select=None):
    output = OUT/f'{label}.json'
    assert not output.exists(), output
    cmd=['docker','exec','-e',f'PYTHONPATH=/study/candidates/{source}/src:/study/candidates/{source}',
         '-e','PYTHONHASHSEED=0',CONTAINER,PYTHON,'-m','pytest','/study/bench_candidates.py',
         '--benchmark-only','--benchmark-json',f'/study/evidence/{label}.json','--benchmark-save-data','-q']
    if select:
        cmd += ['-k',select]
    with (OUT/f'{label}.log').open('w') as log:
        subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
    data=json.loads(output.read_text())
    for bench in data['benchmarks']:
        assert bench['stats']['data'], bench['name']
    print(label, 'complete',flush=True)

mode=sys.argv[1]
if mode=='calibration':
    for pair in range(3):
        for role in (('a','b') if pair%2==0 else ('b','a')):
            run('h000',f'calibration-{pair}-{role}')
elif mode=='screen':
    for hyp,selection in HYPOTHESES.items():
        for role in ('h000',hyp):
            run(role,f'screen-{hyp}-{role}',selection)
elif mode=='official':
    for hyp,selection in HYPOTHESES.items():
        for pair in range(7):
            for role in (('h000',hyp) if pair%2==0 else (hyp,'h000')):
                run(role,f'official-{hyp}-{pair}-{role}',selection)
else:
    raise SystemExit(mode)
