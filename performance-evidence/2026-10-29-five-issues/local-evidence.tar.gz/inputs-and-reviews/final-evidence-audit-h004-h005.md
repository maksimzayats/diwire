# Final independent evidence audit

Verdict: PASS for five narrowly scoped optimization issues. No publication blocker remains in the checked evidence. This is issue research approval, not release or merge approval.

Verified without running new tests or timing:

- Recomputed gains, positive pair counts and maximum individual-process CV from raw JSON for all 11 primary-group cells.
- Recomputed the paired bootstrap intervals with the frozen seed and estimator.
- Checked the fixed seven-pair longer-batch ACTION confirmation against raw results.
- Recomputed all nine broad control cells from their three paired observations. All pass the declared loss and variation limits. They remain screening evidence, not seven-pair equivalence proof.
- Official source fingerprints are stable per role. Each proof differs from baseline in one intended module. Paired lock, runtime, platform and affinity records agree.
- Both sparse boundary probes contain 128 registrations immediately after compile, with all 64 expected closed keys present before resolution.
- Sparse profile artifacts `counts-h005-h000.json` and `counts-h005-h005.json` show 16,384 versus 64 matching calls. The older `profile-h005-*` files are distinct dense-workload evidence and show 4,096 versus 64.
- Each proof's final lint/type log passes. Each final full-suite log has 1,564 passed, nine skipped and 100% configured coverage. Both focused runtime variants have 166 passed per proof. Each final FastAPI log has 11 passed.

Earlier failing lint/test attempts, failed local target thresholds and noisy/calibration results must remain visible. Use final successful logs only for the final quality verdict. State the new hosted target scope and do not claim a general compile, HTTP or production speed gain.

Machine-readable recomputation results: `final-evidence-audit-h004-h005.json` in this thread storage.
