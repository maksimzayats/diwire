import json
import random
import statistics as st
from pathlib import Path
ROOT=Path(__file__).parent
OUT=ROOT/'evidence'

def cells(path):
    return {b['name']:b for b in json.loads(path.read_text())['benchmarks']}

def pair(a,b):
    return {name:100*(a[name]['stats']['mean']/b[name]['stats']['mean']-1) for name in a}

report={}
for h in range(1,6):
    hyp=f'h00{h}'
    if not (OUT/f'calibration-v2-{hyp}-2-b.json').exists():
        continue
    effects={}
    for i in range(3):
        values=pair(cells(OUT/f'calibration-v2-{hyp}-{i}-a.json'),cells(OUT/f'calibration-v2-{hyp}-{i}-b.json'))
        for name,gain in values.items():effects.setdefault(name,[]).append(gain)
    for name,g in effects.items():
        report[name]={'pairs':g,'median':st.median(g),'pass':abs(st.median(g))<=3}
(OUT/'calibration-v2-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print('CALIBRATION V2',len(report),'cells',all(c['pass'] for c in report.values()))
for name,c in report.items():print(name,round(c['median'],3),c['pass'])
for h in range(1,6):
    hyp=f'h00{h}'
    driver_log=(OUT/'official-driver.log').read_text() if (OUT/'official-driver.log').exists() else ''
    if f'official-{hyp}-6-h000 complete' not in driver_log or f'official-{hyp}-6-{hyp} complete' not in driver_log:
        continue
    effects={}
    noise={}
    means={}
    for i in range(7):
        a=cells(OUT/f'official-{hyp}-{i}-h000.json')
        b=cells(OUT/f'official-{hyp}-{i}-{hyp}.json')
        for name,gain in pair(a,b).items():
            effects.setdefault(name,[]).append(gain)
            noise.setdefault(name,[]).extend([a[name]['stats']['stddev']/a[name]['stats']['mean']*100,b[name]['stats']['stddev']/b[name]['stats']['mean']*100])
            means.setdefault(name,{'baseline':[],'candidate':[]})
            means[name]['baseline'].append(a[name]['stats']['mean'])
            means[name]['candidate'].append(b[name]['stats']['mean'])
    rng=random.Random(20261029)
    report={}
    for name,gains in effects.items():
        bs=sorted(st.median(rng.choices(gains,k=7)) for _ in range(10000))
        report[name]={'paired_gains':gains,'median_gain_percent':st.median(gains),'positive_pairs':sum(x>0 for x in gains),'bootstrap95':[bs[249],bs[9749]],'median_round_cv_percent':st.median(noise[name]),'max_round_cv_percent':max(noise[name]),'means_seconds':means[name]}
    (OUT/f'{hyp}-summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(hyp)
    for name,r in report.items(): print(name,round(r['median_gain_percent'],3),r['positive_pairs'],r['bootstrap95'],round(r['median_round_cv_percent'],2))
