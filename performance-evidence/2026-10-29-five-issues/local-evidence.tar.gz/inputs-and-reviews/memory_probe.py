import asyncio,gc,json,sys,tracemalloc,types
from collections.abc import AsyncGenerator,Generator
from dataclasses import make_dataclass
from typing import Generic,TypeVar
from bench_candidates import container
from diwire import Scope,Lifetime
T=TypeVar('T')

def build(h):
 c=container()
 if h=='h001':
  async def resource():
   try:yield object()
   finally:gc.isenabled()
  for i in range(64):c.add_generator(resource,provides=type(f'R{i}',(),{}),scope=Scope.REQUEST)
  c.compile()
 elif h=='h002':
  key=type('Service',(),{})
  c.add(key,scope=Scope.STEP)
  r=c.compile()
  with r.enter_scope(Scope.STEP) as scope:scope.resolve(key)
 elif h=='h003':
  key=type('Service',(),{})
  for i in range(32):c.add(key,component=i,scope=Scope.APP,lifetime=Lifetime.TRANSIENT)
  c.compile()
 elif h=='h004':
  key=type('Resource',(),{})
  previous=key
  chain=[]
  for i in range(32):
   previous=make_dataclass(f'Consumer{i}',[('dependency',previous)])
   chain.append(previous)
  for consumer in reversed(chain):c.add(consumer,scope=Scope.APP)
  def resource():
   try:yield key()
   finally:gc.isenabled()
  c.add_generator(resource,provides=key,scope=Scope.APP)
 elif h=='h005':
  roots=tuple(types.new_class(f'Repo{i}',(Generic[T],)) for i in range(256))
  for root in roots:c.add(root,provides=root,scope=Scope.APP)
  for i,root in enumerate(roots[-64:]):c.add(make_dataclass(f'Consumer{i}',[('repo',root[int])]),scope=Scope.APP)
  c.compile()
 return c
h=sys.argv[1]
warm=build(h)
if warm._root_resolver is not None:warm.close()
del warm;gc.collect()
tracemalloc.start()
c=build(h)
gc.collect()
retained,peak=tracemalloc.get_traced_memory()
if c._root_resolver is not None:c.close()
tracemalloc.stop()
print(json.dumps({'hypothesis':h,'retained_bytes':retained,'peak_bytes':peak,'definition':'Full live graph after compile; h002 includes one explicit STEP visit; h004 includes registration only; h001 holds 64 unused async generators','runtime':sys.version}))
