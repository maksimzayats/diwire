import sys
from pathlib import Path
ROOT=Path(__file__).parent
exec((ROOT/'run_followups.py').read_text().split('# One fixed seven-pair')[0])
for hyp,source,selection in [('h006','h004','late_cleanup_registration'),('h007','h005','sparse_generic_compile')]:
    for i in range(3):
        for role in (('a','b') if i%2==0 else ('b','a')):
            run('h000',f'target-cal-{hyp}-{i}-{role}','/study/bench_targeted.py',selection)
    import json,statistics
    effects={}
    for i in range(3):
        a={b['name']:b for b in json.loads((OUT/f'target-cal-{hyp}-{i}-a.json').read_text())['benchmarks']}
        b={b['name']:b for b in json.loads((OUT/f'target-cal-{hyp}-{i}-b.json').read_text())['benchmarks']}
        for name in a:effects.setdefault(name,[]).append(100*(a[name]['stats']['mean']/b[name]['stats']['mean']-1))
    summary={name:{'pairs':g,'median':statistics.median(g),'pass':abs(statistics.median(g))<=3} for name,g in effects.items()}
    (OUT/f'target-cal-{hyp}-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    if not all(x['pass'] for x in summary.values()):raise SystemExit(f'{hyp} calibration failed')
    for i in range(7):
        for role in (('h000',source) if i%2==0 else (source,'h000')):
            run(role,f'target-{hyp}-{i}-{role}','/study/bench_targeted.py',selection)
