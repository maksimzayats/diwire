import cProfile,json,os,pstats,sys
from pathlib import Path
import diwire
import bench_candidates as bench
import bench_targeted as targeted
class Once:
    extra_info={}
    def pedantic(self,target,*,setup=None,teardown=None,**kwargs):
        args,kw=setup() if setup else ((),{})
        try:target(*args,**kw)
        finally:
            if teardown:teardown(*args,**kw)
label=sys.argv[1]
profile=cProfile.Profile()
profile.enable()
if label=='h001':bench.test_async_gen(Once(),False)
elif label=='h002':bench.test_scope(Once(),'STEP')
elif label=='h003':bench.test_public_all(Once(),'sync')
elif label=='h004':targeted.test_late_cleanup_registration(Once())
elif label=='h005':targeted.test_sparse_generic_compile(Once(),256,64)
profile.disable()
output=Path(sys.argv[2])
profile.dump_stats(str(output.with_suffix('.prof')))
rows=[]
for (file,line,name),values in pstats.Stats(profile).stats.items():
    cc,nc,tt,ct,_=values
    if 'diwire' in file or 'contextlib' in file or file=='<diwire-resolver>':
        rows.append({'file':file,'line':line,'name':name,'primitive_calls':cc,'calls':nc,'self_seconds_profiled_only':tt,'cumulative_seconds_profiled_only':ct})
output.write_text(json.dumps({'imported_source':diwire.__file__,'rows':sorted(rows,key=lambda r:r['cumulative_seconds_profiled_only'],reverse=True)},indent=2)+'\n')
