import os,subprocess
from pathlib import Path
root=Path(__file__).parent
for i in range(1,6):
 h=f'h00{i}'
 work=root/'candidates'/h
 env=dict(os.environ,COMPOSE_PROJECT_NAME=f'diwire-five-proof-{h}-20261029')
 with (root/'evidence'/f'quality-{h}-fastapi-final.log').open('w') as log:
  result=subprocess.run(['make','test-e2e-fastapi'],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(h,'final FastAPI E2E',result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
