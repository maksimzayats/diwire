import json,types
from dataclasses import make_dataclass
from typing import Generic,TypeVar
from bench_candidates import container
from diwire import Scope,Lifetime
T=TypeVar('T')
roots=tuple(types.new_class(f'Repo{i}',(Generic[T],)) for i in range(256))
selected=roots[-64:]
keys=tuple(root[int] for root in selected)
c=container()
for root in roots:c.add(root,provides=root,scope=Scope.APP,lifetime=Lifetime.SCOPED)
for i,key in enumerate(keys):c.add(make_dataclass(f'Consumer{i}',[('repo',key)]),scope=Scope.APP,lifetime=Lifetime.SCOPED)
assert len(c._providers_registrations)==64
c.compile()
assert len(c._providers_registrations)==128
assert all(c._providers_registrations.find_by_type(key) is not None for key in keys)
print(json.dumps({'templates':256,'consumers':64,'registrations_immediately_after_compile':len(c._providers_registrations),'all_closed_keys_registered_before_resolve':True}))
c.close()
