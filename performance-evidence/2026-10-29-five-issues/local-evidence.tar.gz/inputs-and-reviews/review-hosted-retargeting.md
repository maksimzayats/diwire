# Independent audit: hosted retargeting and controller

Reviewed the frozen hosted controller, workflow, target and control workloads, protocol, provenance hook and five proof patches. No tests or timing were run.

## Retargeting verdict

A new hosted study can support narrow issues. It uses a different machine/runtime, states new targets before those runs, retains earlier failures, and keeps the 5% floor and seven-pair criteria. Do not combine its observations with the local study.

The prior full generic compile results do not support a useful general compile gain. They remain rejected under the declared floor. The new late-registration target measures a different public operation dominated by the cleanup reducer. The sparse generic target measures registry matching where many registered generic families are unused. These workload changes must be explicit in each issue.

Truthful possible scopes if all declared gates pass:

- h004: throughput for batched late registration of a resource after a reverse-registered 32-consumer chain. Each round contains 16 independent public registrations, with setup and cleanup verification excluded.
- h005: cold compilation with 256 registered generic families and 64 consumers. This does not establish a dense-generic compile gain or a general startup gain.

Retain the local +4.20% and +0.846% target failures, failed sparse calibration and noisy late-registration result. Do not present a hosted success as a repeat that erased them.

## Controller checks

The primary logic enforces seven paired process observations, a 5% median throughput floor, six positive pairs, positive paired bootstrap lower bound and maximum individual-process CV of 10%. It preserves full raw distributions. Calibration has a single fixed three-pair stage. Secondary noisy runtime cells receive a fixed longer-batch confirmation without pooling or primary rerun. Imported source paths and library/lock/harness hashes are recorded.

The 16-container late-registration adapter keeps original setup, target and teardown boundaries. It retains all containers and runs each lifecycle check. No normal-path work shift was found.

## Publication blocker

The final broad loop records three paired observations per control but never enforces a regression or noise gate. `ALL_PRIMARY_TARGETS_PASSED` can print even if generic registration, dense compile or unused-resource compile has a substantial regression. Treat it only as a primary status. Audit every broad cell before publication. A material loss or unresolved variation requires the declared fixed confirmation or an explicit issue limitation that does not claim a validated acceptable patch. Do not silently treat a green workflow as full acceptance.

## Equivalence check before final claim

The sparse generic benchmark verifies consumers after compile by resolving them. That could hide deferred materialization in a defective candidate. Source review found no such defect in the current origin filter, but verify independently that both roles have exactly 2 * consumer_count closed registrations after compile and that all expected closed keys exist before any teardown resolution. This can use a separate behavior/profile probe without rerunning the primary measurement.

## Final patch review

The current h005 patch fixes the earlier custom-origin hashing and restore guard mismatch. It uses standard-origin lists, retains dictionary order on replacement, derives the restore guard from spec values, and falls back globally for nonstandard origins. No further source-level correctness block was found.
