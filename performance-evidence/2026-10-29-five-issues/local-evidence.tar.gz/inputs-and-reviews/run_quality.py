import os,subprocess
from pathlib import Path
root=Path(__file__).parent
for i in range(1,6):
 h=f'h00{i}'
 work=root/'candidates'/h
 env=dict(os.environ,UV_NO_SYNC='1',UV_PROJECT_ENVIRONMENT='/Users/mac/os/projects/diwire/.venv',PYTHONPATH=f'{work}/src:{work}',DIWIRE_EXPECT_SOURCE=str(work/'src/diwire'))
 for target in ('lint','test'):
  if target=='test':env['PYTEST_ADDOPTS']=str(root/'test_proof_semantics.py')
  with (root/'evidence'/f'quality-{h}-{target}.log').open('w') as log:
   result=subprocess.run(['make',target],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
  print(h,target,result.returncode,flush=True)
