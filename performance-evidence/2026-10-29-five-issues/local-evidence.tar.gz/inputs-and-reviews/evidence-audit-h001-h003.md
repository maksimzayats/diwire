# Independent evidence audit: H001 to H003

Scope: saved local raw JSON, summaries, source hashes, quality logs, frozen hosted controller, and protocols. No tests or timings run by this reviewer.

## Result

The local primary gain calculations are correct. All three primary cells meet the local primary effect, pair-win, confidence-interval, and round-noise rules. Full acceptance remains incomplete because three secondary controls exceed the declared noise limit. The hosted run was still in progress in the inspected status artifact.

| Cell | Median paired throughput gain | Positive pairs | Maximum process CV |
| --- | ---: | ---: | ---: |
| H001 async generator without dependencies | 33.818612% | 7/7 | 8.530144% |
| H002 explicit STEP transition | 23.295814% | 7/7 | 4.562469% |
| H003 public All of sync members | 26.289019% | 7/7 | 9.323383% |

These are medians of paired throughput ratios. They are not arithmetic mean gains or reductions in elapsed time. Each gain was recalculated from all raw timing rounds. Raw means and sample standard deviations exactly match saved pytest-benchmark statistics. Every paired gain exactly matches its summary entry. Bootstrap code samples the seven process-pair effects, which is the correct independence level for this design.

## Local protection blockers

- H001 dependent async generator: max process CV 18.990428%.
- H002 ACTION transition: max process CV 30.344761%.
- H003 mixed All: max process CV 19.474542%.

Their point estimates are positive. That does not override the declared noise limit. Preserve those series and use the predeclared independent hosted experiment or fixed confirmation rules. Do not silently discard noisy roles or pool local ARM64 VM data with hosted data.

## Provenance

Every inspected role across all 42 local H001-H003 process files contains study_provenance. Per-role full-library source hashes are stable across seven pairs. All roles use the same harness hash, protocol hash, lock hash, and affinity [0]. The pytest commit_info field says unversioned, but the separate full-source hashes supply source binding. Bind those hashes to baseline 6f225bf and the exact candidate patches in the report.

The H002 later lint correction only removes a bootstrap local assignment and returns the constructed runtime directly. It does not alter the timed _resolver_enter_scope body. Keep both frozen measurement patch and final quality-checked patch fingerprints. State this small provenance difference. H003's later fixture update is test-only.

## Quality evidence inspected

H001-H003 final lint logs show Ruff and mypy passing. Their complete test logs show 1,564 passed, nine documented skips, and 100% configured coverage. These establish tested behavior for the quality-checked snapshots. The H001 FastAPI final log inspected during this audit still ended at Docker image construction. Do not report that step as passed until its completed result is available.

## Memory tradeoffs

All three local memory pairs for H001 agree: 64 unused async generators add 30,944 retained bytes and 31,000 peak bytes. This is a real compile-time memory cost from prebinding wrappers. Report the absolute cost and workload size. Do not describe H001 as a pure gain with no cost.

H002 adds 315 retained bytes after the measured explicit STEP visit. Its cache is lazy. The timing claim is repeated entry with a warm transition-plan cache. First use still creates the plan.

H003 retained deltas are 277, 277, and 224 bytes in the inspected samples. These are small local observations, not proof of zero memory impact on every workload.

## Hosted controller review

The controller keeps primary estimates fixed and confirms only noisy secondary cells using one seven-pair longer-batch series. It changes the batch for both roles equally. That is a fair independent confirmation boundary, provided original samples remain visible.

The controller saves broad-control JSON but does not enforce thresholds on broad controls before printing ALL_PRIMARY_TARGETS_PASSED. Review the saved broad results manually before accepting or publishing a clean overall verdict.

The frozen controller does not run the complete canonical runtime matrix for H001-H003. If the final issue says canonical runtime protection passed, that requires separate saved evidence. A source-level argument that a path is unchanged is useful but is not a measured matrix result.

## Publication boundary

No blocker to preparing issues with the correctly scoped primary observations. Before publishing them as proven, fully checked optimization opportunities, finish the protected-noise decisions and broad/manual review. Include the exact runtime, baseline, candidate patch, commands, raw evidence links, and H001 memory tradeoff. State that the patches are isolated research proofs, not merged production changes. Do not make HTTP or full-application throughput claims.

## Final audit after hosted evidence and quality completion

Verdict: no remaining blocker to publishing the five scoped optimization issues.

Independently recalculated every hosted official and confirmation cell from its saved raw roles. Paired gains and maximum CV values match the summary within floating-point rounding (largest error about 3.6e-15). Source hashes are stable per role across all pairs. All five primary targets have seven positive pairs, exceed the declared 5% effect floor, have positive lower confidence bounds, and stay below the declared 10% process CV ceiling.

Hosted primary median throughput gains are H001 21.276371%, H002 23.767495%, H003 32.852337%, H004 37.243250%, and H005 9.072757%. These are independent Linux x86_64 CPython 3.14.10 measurements. Do not pool them with local ARM64 Docker VM values.

The prior protected-noise blockers are resolved by the hosted series. H001 with dependencies is stable. H002 ACTION uses its one fixed longer-batch confirmation, which gains 23.312315% with max CV 2.230213%. H003 mixed is stable with median -1.720672%, inside the -5% protection floor. Preserve that small loss in the issue, rather than claiming every scenario improves.

Manual review of broad summary files confirms their median effects and CV values are within the declared limits. The worst observed broad median is -0.202844%; maximum broad CV is 5.657242%. This closes the controller's missing automatic broad-decision gate for this publication. It does not turn the tested broad subset into the full canonical runtime matrix.

I independently reconstructed the frozen measured H002 compiler from the final lint-clean compiler. Its hash exactly matches e60c77e3b7d3eef9481802a6c5ba6b7a743353e9fb8209ebd152f199ff731624. I independently verified that the timed _resolver_enter_scope AST is identical. The untimed bootstrap-only lint adjustment is therefore accounted for.

Read all five final FastAPI E2E logs: each reports 11 passed. The driver records exit 0 for each. The quality summary records 1,564 full tests, 100% coverage, clean lint/typing, and 166 focused tests on each Python 3.10 and Python 3.14t per candidate. Earlier inspected H001-H003 logs independently confirmed their full-suite and lint results.

Publication should keep H001's 30,944-byte retained-memory cost for 64 unused generators, H003's small mixed-control loss, and each workload boundary. These are isolated proof patches and scoped optimization opportunities. They do not establish a merged implementation, a full application speedup, or HTTP throughput gains.

No tests or timing runs were performed by this reviewer at any audit stage.
